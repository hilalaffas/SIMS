import React, { useState, useRef, useEffect } from "react";

/**
 * ActionReasonPreview.jsx
 * ------------------------------------------------------------------
 * Preview interaktif (bukan bagian dari struktur file asli project).
 * Mensimulasikan alur baru: klik ACC/Revisi/Tolak -> muncul modal
 * alasan -> submit -> status & riwayatLog ter-update.
 * Dibuat hanya untuk kamu coba rasakan UX-nya langsung di chat ini.
 * ------------------------------------------------------------------
 */

const ACTION_CONFIG = {
  acc: {
    accent: "emerald",
    modalTitle: "Setujui Permohonan Cuti",
    modalSubtitle: "Konfirmasi persetujuan & tambahkan catatan untuk pemohon.",
    submitLabel: "Ya, Setujui",
    placeholder: "Contoh: Disetujui, pastikan pekerjaan sudah di-handover sebelum cuti.",
    statusValue: "DISETUJUI",
    badgeClass: "bg-emerald-50 text-emerald-600 border-emerald-100",
  },
  revisi: {
    accent: "amber",
    modalTitle: "Kembalikan untuk Revisi",
    modalSubtitle: "Jelaskan apa yang perlu dilengkapi/diperbaiki oleh pemohon.",
    submitLabel: "Kembalikan",
    placeholder: "Contoh: Mohon lampirkan surat pendukung terlebih dahulu.",
    statusValue: "DIKEMBALIKAN",
    badgeClass: "bg-amber-50 text-amber-600 border-amber-100",
  },
  tolak: {
    accent: "rose",
    modalTitle: "Tolak Permohonan Cuti",
    modalSubtitle: "Berikan alasan penolakan yang jelas untuk pemohon.",
    submitLabel: "Ya, Tolak",
    placeholder: "Contoh: Bertepatan dengan jadwal rilis, mohon ajukan tanggal lain.",
    statusValue: "DITOLAK",
    badgeClass: "bg-rose-50 text-rose-600 border-rose-100",
  },
};

const initialPending = [
  {
    id: "REQ-0001",
    karyawan: { nama: "Nisa Pratiwi", kode: "SYS-2026-0019", jabatan: "UI/UX Designer" },
    jenisCuti: "Cuti setengah hari (Pagi)",
    durasi: "25 Jun 2026 (0.5 Hari)",
    keterangan: "Kontrol gigi",
    statusBerkas: "PROSES",
    riwayatLog: [
      { nama: "Nisa Pratiwi", waktu: "2026-06-24 10:00", statusBadge: "DIAJUKAN", catatan: "Mengajukan sesi pagi untuk kontrol ke dokter gigi." },
    ],
  },
  {
    id: "REQ-0002",
    karyawan: { nama: "Andi Santoso", kode: "SYS-2026-0042", jabatan: "Backend Engineer" },
    jenisCuti: "Cuti Tahunan",
    durasi: "25-27 Jun 2026 (3 Hari)",
    keterangan: "Acara keluarga",
    statusBerkas: "PROSES",
    riwayatLog: [
      { nama: "Andi Santoso", waktu: "2026-06-20 09:00", statusBadge: "DIAJUKAN", catatan: "Mengirim draf awal pengajuan." },
    ],
  },
];

const formatLogTimestamp = (date) => {
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

function ActionReasonModal({ request, onCancel, onSubmit }) {
  const [alasan, setAlasan] = useState("");
  const [touched, setTouched] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (request) {
      setAlasan("");
      setTouched(false);
      const t = setTimeout(() => ref.current?.focus(), 50);
      return () => clearTimeout(t);
    }
  }, [request]);

  if (!request) return null;
  const config = ACTION_CONFIG[request.action];
  const isValid = alasan.trim().length >= 5;

  const ring = {
    emerald: "focus:ring-emerald-200 focus:border-emerald-500",
    amber: "focus:ring-amber-200 focus:border-amber-500",
    rose: "focus:ring-rose-200 focus:border-rose-500",
  }[config.accent];

  const headerBg = {
    emerald: "bg-gradient-to-br from-emerald-600 to-emerald-800",
    amber: "bg-gradient-to-br from-amber-600 to-amber-800",
    rose: "bg-gradient-to-br from-rose-600 to-rose-800",
  }[config.accent];

  const btnBg = {
    emerald: "bg-emerald-600 hover:bg-emerald-700",
    amber: "bg-amber-600 hover:bg-amber-700",
    rose: "bg-rose-600 hover:bg-rose-700",
  }[config.accent];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-sm p-6"
      onMouseDown={onCancel}
    >
      <div
        className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden animate-[popIn_0.2s_ease]"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className={`${headerBg} text-white px-6 py-5`}>
          <h2 className="text-[15px] font-bold">{config.modalTitle}</h2>
          <p className="text-[12.5px] text-white/80 mt-1">{config.modalSubtitle}</p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            setTouched(true);
            if (!isValid) return;
            onSubmit(request.item.id, request.action, alasan.trim());
          }}
        >
          <div className="px-6 pt-5 pb-2 flex flex-col gap-2">
            <div className="rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5">
              <div className="text-[13.5px] font-bold text-gray-800">{request.item.karyawan.nama}</div>
              <div className="text-[12px] text-gray-500">{request.item.jenisCuti} · {request.item.durasi}</div>
            </div>

            <label className="text-[11px] font-bold uppercase tracking-wide text-gray-400 mt-2">
              Alasan / Catatan
            </label>
            <textarea
              ref={ref}
              rows={4}
              className={`w-full border border-gray-200 rounded-xl px-3 py-2.5 text-[13.5px] outline-none focus:ring-4 ${ring}`}
              placeholder={config.placeholder}
              value={alasan}
              onChange={(e) => setAlasan(e.target.value)}
              onBlur={() => setTouched(true)}
            />
            {touched && !isValid ? (
              <span className="text-[12px] font-semibold text-rose-600">Alasan wajib diisi (minimal 5 karakter).</span>
            ) : (
              <span className="text-[12px] text-gray-400">Catatan ini akan tercatat di riwayat log berkas.</span>
            )}
          </div>

          <div className="flex justify-end gap-2 px-6 py-4 mt-2 border-t border-gray-100">
            <button type="button" onClick={onCancel} className="px-4 py-2 rounded-xl text-[13px] font-bold text-gray-500 border border-gray-200 hover:bg-gray-50">
              Batal
            </button>
            <button type="submit" disabled={!isValid} className={`px-5 py-2 rounded-xl text-[13px] font-bold text-white disabled:opacity-50 disabled:cursor-not-allowed ${btnBg}`}>
              {config.submitLabel}
            </button>
          </div>
        </form>
      </div>
      <style>{`@keyframes popIn { from { opacity:0; transform: translateY(10px) scale(.97);} to {opacity:1; transform: translateY(0) scale(1);} }`}</style>
    </div>
  );
}

export default function ActionReasonPreview() {
  const [pending, setPending] = useState(initialPending);
  const [actionRequest, setActionRequest] = useState(null);
  const [detailItem, setDetailItem] = useState(null);

  const handleConfirm = (id, action, alasan) => {
    const config = ACTION_CONFIG[action];
    const logEntry = {
      nama: "Anda (Approver)",
      waktu: formatLogTimestamp(new Date()),
      statusBadge: config.statusValue,
      catatan: alasan,
    };
    setPending((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, statusBerkas: config.statusValue, riwayatLog: [...item.riwayatLog, logEntry] }
          : item
      )
    );
    setActionRequest(null);
  };

  return (
    <div className="min-h-[520px] bg-slate-50 p-6 font-sans">
      <h1 className="text-lg font-bold text-gray-800 mb-1">Preview: Alasan ACC / Revisi / Tolak</h1>
      <p className="text-[13px] text-gray-500 mb-5">
        Klik salah satu tombol aksi di bawah — modal alasan akan muncul, status &amp; riwayat log baru ter-update setelah submit.
      </p>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {pending.map((item) => {
          const isDone = item.statusBerkas !== "PROSES";
          const badge = ACTION_CONFIG[
            item.statusBerkas === "DISETUJUI" ? "acc" : item.statusBerkas === "DIKEMBALIKAN" ? "revisi" : "tolak"
          ]?.badgeClass;
          return (
            <div key={item.id} className="flex items-center justify-between gap-4 px-5 py-4 border-b border-gray-50 last:border-0">
              <div>
                <div className="text-[14px] font-bold text-gray-800">
                  {item.karyawan.nama} <span className="text-[12px] font-normal text-gray-400">({item.karyawan.kode})</span>
                </div>
                <div className="text-[12.5px] text-gray-500">{item.jenisCuti} · {item.durasi}</div>
              </div>

              <div className="flex items-center gap-2">
                {isDone ? (
                  <span className={`text-[11px] font-bold px-3 py-1 rounded-full border ${badge}`}>{item.statusBerkas}</span>
                ) : (
                  <>
                    <button onClick={() => setActionRequest({ item, action: "acc" })} className="px-3 py-1.5 rounded-lg text-[12px] font-bold bg-emerald-50 text-emerald-600 border border-emerald-100 hover:bg-emerald-600 hover:text-white transition-colors">ACC</button>
                    <button onClick={() => setActionRequest({ item, action: "revisi" })} className="px-3 py-1.5 rounded-lg text-[12px] font-bold bg-amber-50 text-amber-600 border border-amber-100 hover:bg-amber-600 hover:text-white transition-colors">Revisi</button>
                    <button onClick={() => setActionRequest({ item, action: "tolak" })} className="px-3 py-1.5 rounded-lg text-[12px] font-bold bg-rose-50 text-rose-600 border border-rose-100 hover:bg-rose-600 hover:text-white transition-colors">Tolak</button>
                  </>
                )}
                <button onClick={() => setDetailItem(item)} className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-gray-50" title="Lihat log">
                  ⏱
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {detailItem && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-6" onMouseDown={() => setDetailItem(null)}>
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-5" onMouseDown={(e) => e.stopPropagation()}>
            <h3 className="text-[14px] font-bold text-gray-800 mb-3">Riwayat Log — {detailItem.karyawan.nama}</h3>
            <div className="flex flex-col gap-2 max-h-64 overflow-y-auto">
              {detailItem.riwayatLog.map((log, i) => (
                <div key={i} className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                  <div className="flex justify-between text-[12.5px]">
                    <span className="font-bold text-gray-700">{log.nama}</span>
                    <span className="text-gray-400">{log.waktu}</span>
                  </div>
                  <div className="flex gap-2 mt-1 items-start">
                    <span className="text-[10px] font-bold uppercase bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded">{log.statusBadge}</span>
                    <span className="text-[12.5px] text-gray-600">{log.catatan}</span>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={() => setDetailItem(null)} className="mt-4 w-full bg-[#123d2f] text-white rounded-lg py-2 text-[13px] font-bold">Tutup</button>
          </div>
        </div>
      )}

      <ActionReasonModal request={actionRequest} onCancel={() => setActionRequest(null)} onSubmit={handleConfirm} />
    </div>
  );
}
